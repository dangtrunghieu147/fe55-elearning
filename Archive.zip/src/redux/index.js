import { createStore, combineReducers } from "redux";

const reducer = combineReducers({
  //state in store
});

const store = createStore(reducer);
